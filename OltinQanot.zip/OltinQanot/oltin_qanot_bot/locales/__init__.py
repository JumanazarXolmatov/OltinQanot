"""Locales package initialization"""
